﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBSchool.Interface
{
    public enum OperateTypeEnum
    {
        None = 0,
        Insert = 1,
        Edit = 2,
        View = 4,
        Delete = 8
    }
}
