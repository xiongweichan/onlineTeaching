﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBSchool.Interface
{
    public interface IBootstrap : IRendering
    {
    }
}
