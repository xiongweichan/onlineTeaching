﻿using Caliburn.Micro;
using NBSchool.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBSchool.WPFClient.ViewModels
{
    [Export(typeof(IRegister))]
    public class RegisterViewModel : Conductor<IRendering>.Collection.OneActive, IRendering, IRegister
    {
        RegisterInfoViewModel _CurrentContent;

        public RegisterInfoViewModel CurrentContent
        {
            get
            {
                return _CurrentContent;
            }
            set
            {
                this.Set(ref _CurrentContent, value);
            }
        }

        public OperateTypeEnum OperateType { get; set; }

        public void DeActivateView(object activateViewModel, object deActivateViewModel)
        {
            //throw new NotImplementedException();
        }

        public RegisterViewModel()
        {

            CurrentContent = new RegisterInfoViewModel();
        }
    }
}
