﻿using Caliburn.Micro;
using NBSchool.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBSchool.WPFClient.ViewModels
{
    [Export(typeof(IBootstrap))]
    public class LoginViewModel : Conductor<IRendering>.Collection.OneActive, IBootstrap
    {

        public LoginViewModel()
        {
            base.DisplayName = "邻居学院 登录窗口";
        }


        public void RegisterAccount()
        {
            object obj = IoC.Get<IRegister>();
            IoC.Get<IWindowManager>().ShowDialog(obj);
        }

        public void DeActivateView(object activateViewModel, object deActivateViewModel)
        {
        }
    }
}
