﻿using System.Windows;

namespace NBSchool.WPFClient.Controls
{
    public interface IThemeManager
    {
        ResourceDictionary GetThemeResources();
    }
}